// Express initialization
var express = require('express');
var app = express();
app.use(express.bodyParser());
app.set('title', 'scorecenter');

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});


app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });
 

app.get('/highscores.json', function (request, response) {
	var jsonString="";
		db.collection("highscores", function(err, collection){
				jsonString = collection.find({ game_title: request.query.game_title } ).sort( {score: -1}).limit(10).toArray();
			});
		response.set('Content-Type', 'text/json');
		response.send(jsonString);
});

app.get('/', function(request, response) {
	var jsonString ="";
	var htmlString = "<html><body>";
	db.collection("highscores", function(err, collection){
			jsonString = collection.find().sort( {game_title: -1, score: -1}).toArray(function(err, results){
				for(var i = 0; i<results.length(); i++){
		if(i==0){
			htmlString+="<b>"+results[0].game_title+": </b><br />";
		}
		if(i>0&&results[i-1].game_title!==results[i].game_title){
			htmlString+="<br /><b>"+results[i].game_title+": </b><br />";
			}
		htmlString+=results[i].username+": "+results[i].score+"<br />";
		}
	})});
	htmlString+="</body></html>";
	response.set('Content-Type', 'text/html');
	response.send(htmlString);
});

app.get('/submit.json', function(request, response) {
		var d = new Date();
			db.collection("highscores", function(err, collection){
				collection.insert({ game_title: request.query.game_title, username: request.query.username, score:request.query.score , created_at: d});
		});
	response.send("<p>Inputted correctly</p>");
});

app.get('/usersearch', function(request, response) {
	var htmlString ="<html><body>";
	htmlString +="<form name='input' action='searchresults' method='get'> Username: <input type='text' name='username'> <input type='submit' value='Submit'></form></body></html>";
	response.set('Content-Type', 'text/html');
	response.send(htmlString);
});

app.get('/searchresults', function(request, response) {
	var jsonString ="";
	var htmlString = "<html><body>";
	db.collection("highscores", function(err, collection){
			jsonString = collection.find({ username: request.query.username } ).sort( {game_title: -1, score: -1}).toArray(function(err, results){
				for(var i = 0; i<results.length; i++){
		if(i==0){
			htmlString+="<b>"+results[0].game_title+": </b><br />";
		}
		if(i>0&&results[i-1].game_title!==results[i].game_title){
			htmlString+="<br /><b>"+results[i].game_title+": </b><br />";
			}
		htmlString+=results[i].username+": "+results[i].score+"<br />";
		}
	})});
			
	htmlString+="</body></html>";
	response.set('Content-Type', 'text/html');
	response.send(htmlString);
});
//my tester function to insert items into the database
app.get('/tester', function(request, response) {
	var htmlString='<html><body><form name="input" action="submit.json" method="get"> Username: <input type="text" name="username"> Game Title: <input type="text" name="game_title"> Score: <input type="text" name="score"> <input type="submit" value="Submit"></form></body></html';
	response.send(200, htmlString);
});



// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);